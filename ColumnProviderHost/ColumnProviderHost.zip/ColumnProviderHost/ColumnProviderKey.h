#pragma once
class ColumnProviderKey
{
public:
	ColumnProviderKey(void);
	~ColumnProviderKey(void);
	CString classId;
	CString description;
};

