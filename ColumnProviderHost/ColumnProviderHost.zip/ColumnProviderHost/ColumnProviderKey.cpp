#include "StdAfx.h"
#include "ColumnProviderKey.h"


ColumnProviderKey::ColumnProviderKey(void)
{
}


ColumnProviderKey::~ColumnProviderKey(void)
{
}
